#!/bin/bash
#
#   Copyright 2014 UnboundID Corp.
#
#

cd "`dirname "${0}"`"
SCRIPT_DIR=`pwd`

#CLASSPATH="-classpath $SCRIPT_DIR/../lib/sync-oracle-sp.jar"
CLASSPATH="-classpath $SCRIPT_DIR/../build/com.unboundid.labs.sync-oracle-sp-1.15.1/sync-oracle-sp.jar"
TOOL="java $CLASSPATH com.unboundid.labs.OracleSPTool"

usage() {
echo "Usage: $0"
exit 1
}

$TOOL
