-- Run the following as the SYS or other DBA user
--
drop user SYNC_SERVICE cascade;

create user SYNC_SERVICE identified by SYNC_SERVICE default tablespace users;

grant connect, resource, create any table, drop any table, update any table, insert any table to SYNC_SERVICE;
--

-- Run the following section as the SYNC_SERVICE user
--
  CREATE TABLE "SYNC_SERVICE"."PERSON"
   (	"USERID" VARCHAR2(100 BYTE) NOT NULL ENABLE,
	"FNAME" VARCHAR2(32 BYTE),
	"LNAME" VARCHAR2(32 BYTE),
	"EMPLOYEEID" NUMBER,
	"DBCREATETIME" DATE,
	"DBMODIFYTIME" DATE,
	"DBMODIFIEDBY" VARCHAR2(50 BYTE),
	 CONSTRAINT "PERSON_PK" PRIMARY KEY ("USERID"));

  CREATE TABLE "SYNC_SERVICE"."PERSON_CONTACT"
   (	"USERID" VARCHAR2(100 BYTE) NOT NULL ENABLE,
	"ADDRESS1" VARCHAR2(100 BYTE),
	"ADDRESS2" VARCHAR2(100 BYTE),
	"CITY" VARCHAR2(50 BYTE),
	"STATE" VARCHAR2(50 BYTE),
	"ZIP" VARCHAR2(10 BYTE),
	"DBCREATETIME" DATE,
	"DBMODIFYTIME" DATE,
	"DBMODIFIEDBY" VARCHAR2(50 BYTE),
	 CONSTRAINT "PERSON_CONTACT_PK" PRIMARY KEY ("USERID"));

   CREATE TABLE "SYNC_SERVICE"."PERSON_PREFERENCE"
   (    "USERID" VARCHAR2(100 BYTE) NOT NULL ENABLE,
        "PREF" VARCHAR2(100 BYTE) NOT NULL ENABLE,
        "DBCREATETIME" DATE,
        "DBMODIFYTIME" DATE,
        "DBMODIFIEDBY" VARCHAR2(50 BYTE),
        CONSTRAINT "PERSON_PREFERENCE_PK" PRIMARY KEY ("USERID", "PREF"));

-- Run the following section as the SYNC_SERVICE group
--
  CREATE TABLE "SYNC_SERVICE"."GROUP"
   (	"GROUPID" VARCHAR2(32 BYTE) NOT NULL ENABLE,
	"NAME" VARCHAR2(32 BYTE),
	"DESCRIPTION" VARCHAR2(100 BYTE),
	"DBCREATETIME" DATE,
	"DBMODIFYTIME" DATE,
	"DBMODIFIEDBY" VARCHAR2(50 BYTE),
	 CONSTRAINT "GROUP_PK" PRIMARY KEY ("GROUPID"));

-- Run the following section as the SYNC_SERVICE user_group
--
  CREATE TABLE "SYNC_SERVICE"."USER_GROUP"
   (	"GROUPID" VARCHAR2(32 BYTE) NOT NULL ENABLE,
        "USERID" VARCHAR2(100 BYTE) NOT NULL,
	"DBCREATETIME" DATE,
	"DBMODIFYTIME" DATE,
	"DBMODIFIEDBY" VARCHAR2(50 BYTE),
	 CONSTRAINT "USER_GROUP_PK" PRIMARY KEY ("GROUPID", "USERID"));

CREATE TABLE "SYNC_SERVICE"."CHANGELOG" (
    --This is the unique number for the change
    CHANGE_NUMBER       Number NOT NULL PRIMARY KEY,
    --This is the type of change (insert, update, delete). NOTE: This should
    --represent the actual type of change that needs to happen on the destination
    --(for example a database delete might translate to a LDAP modify, etc.)
    CHANGE_TYPE         VARCHAR2(10) NOT NULL,
    --This is the name of the table that was changed
    TABLE_NAME          VARCHAR2(50) NOT NULL,
    --This is the unique identifier for the row that was changed. It is up to the
    --trigger code to construct this, but it should follow a DN-like format
    --(e.g. accountID={accountID}) where at least the primary key(s) are present.
    --If multiple primary keys are required, they should be delimited with a unique
    --string such as '%%' (e.g. accountID={accountID}%%groupID={groupID})
    IDENTIFIER          VARCHAR2(100) NOT NULL,
    --This is the database entry type. The allowable values for this must be set
    --on the JDBC Sync Source configuration within the Identity Data Sync Server.
    ENTRY_TYPE          VARCHAR2(50) NOT NULL,
    --This is a comma-separated list of columns that were updated as part of this change
    CHANGED_COLUMNS     VARCHAR2(1000) NULL,
    --This is the name of the database user who made the change
    MODIFIERS_NAME      VARCHAR2(100) NOT NULL,
    --This is the timestamp of the change
    CHANGE_TIME         TIMESTAMP(3) NOT NULL,
   CONSTRAINT chk_change_type CHECK (change_type IN ('insert', 'delete', 'update'))
   );

CREATE SEQUENCE "SYNC_SERVICE"."CHANGELOG_SEQ" MINVALUE 1 START WITH 1 NOMAXVALUE INCREMENT BY 1 CACHE 100 NOCYCLE;

-- Create an Oracle Trigger
CREATE OR REPLACE EDITIONABLE TRIGGER "SYNC_SERVICE"."SYNC_SERVICE_PERSON_TRG"
AFTER INSERT OR DELETE OR UPDATE ON "SYNC_SERVICE"."PERSON"
FOR EACH ROW
DECLARE
  my_identifier changelog.identifier%TYPE;
  my_changetype changelog.change_type%TYPE;
  my_changedcolumns changelog.changed_columns%TYPE := '';
  CURSOR column_cursor IS select COLUMN_NAME from USER_TAB_COLUMNS where TABLE_NAME='PERSON';
BEGIN
  --Short circuit and do nothing if the change came from the Identity Data Sync Server itself.
  --This prevents loopbacks when doing bi-directional synchronization.
  IF UPPER(USER) = UPPER('SYNC_SERVICE') THEN
    RETURN;
  END IF;
  -- Figure out change type
  IF INSERTING THEN
    my_identifier := 'USERID=' || :NEW.userid;
    my_changetype := 'insert';
  ELSIF DELETING THEN
    my_identifier := 'USERID=' || :OLD.userid;
    my_changetype := 'delete';
  ELSIF UPDATING THEN
    my_identifier := 'USERID=' || :NEW.userid;
    my_changetype := 'update';

    --Figure out changed columns
    FOR my_row IN column_cursor
    LOOP
      IF UPDATING (my_row.COLUMN_NAME) THEN
        my_changedcolumns := my_changedcolumns || my_row.COLUMN_NAME || ',';
      END IF;
    END LOOP;
  END IF;

  --Do the insert
  INSERT INTO changelog (change_number, change_type, table_name, identifier, entry_type, changed_columns, modifiers_name, change_time)
    VALUES (changelog_seq.NEXTVAL, my_changetype, 'PERSON', my_identifier, 'PERSON', my_changedcolumns, USER, SYSTIMESTAMP);

    --If changes to this table affect multiple LDAP entries, multiple records should be inserted into the changelog table.
    --For example, if an update to an "account" in the database affected an "account" LDAP entry and a "groups" LDAP entry,
    --then we would have another "INSERT INTO CHANGELOG..." here with a different entry type.

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Changelog trigger exception:');
    DBMS_OUTPUT.PUT_LINE(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;

ALTER TRIGGER "SYNC_SERVICE"."SYNC_SERVICE_PERSON_TRG" ENABLE;

-- Create an Oracle Trigger
CREATE OR REPLACE EDITIONABLE TRIGGER "SYNC_SERVICE"."SYNC_SERVICE_GROUP_TRG"
AFTER INSERT OR DELETE OR UPDATE ON "SYNC_SERVICE"."GROUP"
FOR EACH ROW
DECLARE
  my_identifier changelog.identifier%TYPE;
  my_changetype changelog.change_type%TYPE;
  my_changedcolumns changelog.changed_columns%TYPE := '';
  CURSOR column_cursor IS select COLUMN_NAME from USER_TAB_COLUMNS where TABLE_NAME='GROUP';
BEGIN
  --Short circuit and do nothing if the change came from the Identity Data Sync Server itself.
  --This prevents loopbacks when doing bi-directional synchronization.
  IF UPPER(USER) = UPPER('SYNC_SERVICE') THEN
    RETURN;
  END IF;
  -- Figure out change type
  IF INSERTING THEN
    my_identifier := 'GROUPID=' || :NEW.groupid;
    my_changetype := 'insert';
  ELSIF DELETING THEN
    my_identifier := 'GROUPID=' || :OLD.groupid;
    my_changetype := 'delete';
  ELSIF UPDATING THEN
    my_identifier := 'GROUPID=' || :NEW.groupid;
    my_changetype := 'update';

    --Figure out changed columns
    FOR my_row IN column_cursor
    LOOP
      IF UPDATING (my_row.COLUMN_NAME) THEN
        my_changedcolumns := my_changedcolumns || my_row.COLUMN_NAME || ',';
      END IF;
    END LOOP;
  END IF;

  --Do the insert
  INSERT INTO changelog (change_number, change_type, table_name, identifier, entry_type, changed_columns, modifiers_name, change_time)
    VALUES (changelog_seq.NEXTVAL, my_changetype, 'GROUP', my_identifier, 'GROUP', my_changedcolumns, USER, SYSTIMESTAMP);

    --If changes to this table affect multiple LDAP entries, multiple records should be inserted into the changelog table.
    --For example, if an update to an "account" in the database affected an "account" LDAP entry and a "groups" LDAP entry,
    --then we would have another "INSERT INTO CHANGELOG..." here with a different entry type.

EXCEPTION
  WHEN OTHERS THEN
    DBMS_OUTPUT.PUT_LINE('Changelog trigger exception:');
    DBMS_OUTPUT.PUT_LINE(DBMS_UTILITY.FORMAT_ERROR_BACKTRACE);
END;

ALTER TRIGGER "SYNC_SERVICE"."SYNC_SERVICE_GROUP_TRG" ENABLE;

