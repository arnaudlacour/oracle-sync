CREATE OR REPLACE PROCEDURE SP_INSERT_PERSON
(
 USERID           IN VARCHAR2
,FNAME            IN VARCHAR2
,LNAME            IN VARCHAR2
,EMPLOYEEID       IN NUMBER
,ADDRESS1         IN VARCHAR2
,ADDRESS2         IN VARCHAR2
,CITY             IN VARCHAR2
,STATE            IN VARCHAR2
,ZIP              IN VARCHAR2

) AS

BEGIN

  INSERT INTO SYNC_SERVICE.PERSON (
        USERID
        ,FNAME
        ,LNAME
        ,EMPLOYEEID
        ,DBCREATETIME
        ,DBMODIFYTIME
        ,DBMODIFIEDBY
  )
  VALUES (
        USERID
        ,FNAME
        ,LNAME
        ,EMPLOYEEID
        ,sysdate
        ,null
        ,USER
  );

  INSERT INTO SYNC_SERVICE.PERSON_CONTACT (
        USERID
        ,ADDRESS1
        ,ADDRESS2
        ,CITY
        ,STATE
        ,ZIP
        ,DBCREATETIME
        ,DBMODIFYTIME
        ,DBMODIFIEDBY
  )
  VALUES (
        USERID
        ,ADDRESS1
        ,ADDRESS2
        ,CITY
        ,STATE
        ,ZIP
        ,sysdate
        ,null
        ,USER
  );

  COMMIT;
END SP_INSERT_PERSON;
