#!/bin/bash
#
#   Copyright 2014 UnboundID Corp.
#
#

SCRIPT_DIR="`dirname "${0}"`"

CLASSPATH="-classpath $SCRIPT_DIR/../sync-oracle-sp.jar:$SCRIPT_DIR/lib/ojdbc6.jar"
SQL="java $CLASSPATH com.unboundid.labs.QueryOracle"

usage() {
echo "Usage: $0"
exit 1
}

###########################################################################
###########################################################################

echo "#"
echo "# This is just a poor man's Java JDBC implementation to mimic a sqlplus like "
echo "# Command Line tool.  "
echo "#"
echo "# To change the location of your Oracle DB Server, edit the sql.properties file."
echo "#"
echo "# To run a query, simply type the select statement, no need to end with a semicolon."
echo "#"
echo "# Example:"
echo "#     SELECT sysdate from dual"
echo "#"
$SQL
