#!/bin/bash

LDAPMODIFY=ds01/bin/ldapmodify

$LDAPMODIFY << EOA1
dn: uid=test.1,ou=People,dc=example,dc=com
changetype: add
objectClass: inetOrgPerson
cn: Test User 1
sn: User 1
employeeNumber: 123456789
givenName: Test
street: 1234 Main
st: TX
l: Anytown
uid: test.1
EOA1

$LDAPMODIFY << EOA2
dn: uid=test.2,ou=People,dc=example,dc=com
changetype: add
objectClass: inetOrgPerson
cn: Test User 2
sn: User 2
employeeNumber: 223456789
givenName: Test
street: 2234 Main
st: TX
l: Anytown
uid: test.2
businessCategory: cn=user.1,ou=people,dc=example,dc=com
businessCategory: uid=user.2,ou=people,dc=example,dc=com
EOA2

echo -n "Press enter to continue..."; read

$LDAPMODIFY << EOM1
dn: uid=test.1,ou=People,dc=example,dc=com
changetype: modify
add: businessCategory
businessCategory: cn=user.1,ou=people,dc=example,dc=com
businessCategory: uid=user.2,ou=people,dc=example,dc=com
EOM1

$LDAPMODIFY << EOM2
dn: uid=test.2,ou=People,dc=example,dc=com
changetype: modify
delete: businessCategory
EOM2

echo -n "Press enter to continue..."; read

$LDAPMODIFY << EOD1
dn: uid=test.1,ou=People,dc=example,dc=com
changetype: delete
EOD1

$LDAPMODIFY << EOD2
dn: uid=test.2,ou=People,dc=example,dc=com
changetype: delete
EOD2

echo -n "Press enter to continue..."; read