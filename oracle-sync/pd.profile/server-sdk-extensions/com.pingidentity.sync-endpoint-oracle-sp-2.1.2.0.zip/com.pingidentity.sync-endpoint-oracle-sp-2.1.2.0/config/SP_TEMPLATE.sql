--
-- OracleSPSync Database Properties
--
-- Copyright 2014-2016 UnboundID Corp.
--
-- Version 1.12 (02/23/16)
--

--
-- Stored Procedure for FETCH of --SYNC_CLASS--
--
-- Returns 1 row based on the --PRIMARY_KEY-- passed.
--
CREATE OR REPLACE PROCEDURE SP_FETCH_--SYNC_CLASS--
(
   --PRIMARY_KEY-- IN VARCHAR2
  ,RESULTS OUT SYS_REFCURSOR
) AS

BEGIN
   OPEN RESULTS FOR
        SELECT
              *
         FROM --TABLE_NAME--
        WHERE --TABLE_NAME--.--PRIMARY_KEY-- = SP_FETCH_--SYNC_CLASS--.--PRIMARY_KEY--

  COMMIT;
END SP_FETCH_--SYNC_CLASS--;


--
-- Stored Procedure for LISTALL of --SYNC_CLASS--
--
-- Returns all the --PRIMARY_KEY-- values from the --TABLE_NAME-- table.
--
CREATE OR REPLACE PROCEDURE SP_LISTALL_--SYNC_CLASS--
(
  RESULTS OUT SYS_REFCURSOR
) AS

BEGIN
  OPEN RESULTS FOR
  SELECT --PRIMARY_KEY--
    FROM --TABLE_NAME--
  ORDER BY --PRIMARY_KEY-- ASC;

END SP_LISTALL_--SYNC_CLASS--;


--
-- Stored Procedure for INSERT of --SYNC_CLASS--
--
-- Inserts a row into the --TABLE_NAME-- based on the parameters passed in.
--
CREATE OR REPLACE PROCEDURE SP_INSERT_--SYNC_CLASS--
(
  --PRIMARY_KEY--   IN VARCHAR2
  ,ATTR1            IN VARCHAR2
  ,ATTR2            IN VARCHAR2
  ,ATTR3            IN NUMBER
) AS

BEGIN

  INSERT INTO --TABLE_NAME-- (
        --PRIMARY_KEY--
        ,ATTR1
        ,ATTR2
        ,ATTR3
        ,DBCREATETIME
        ,DBMODIFYTIME
        ,DBMODIFIEDBY
  )
  VALUES (
        --PRIMARY_KEY--
        ,ATTR1
        ,ATTR2
        ,ATTR3
        ,sysdate
        ,null
        ,USER
  );

  COMMIT;
END SP_INSERT_--SYNC_CLASS--;

--
-- Stored Procedure for UPDATE of --SYNC_CLASS--
--
-- Updates a row in the --TABLE_NAME-- based on the parameters passed in.
--
CREATE OR REPLACE PROCEDURE SP_UPDATE_--SYNC_CLASS--
(
  --PRIMARY_KEY--   IN VARCHAR2
  ,ATTR1            IN VARCHAR2
  ,ATTR2            IN VARCHAR2
  ,ATTR3            IN NUMBER
) AS

BEGIN

  UPDATE --TABLE_NAME--
  SET
    --PRIMARY_KEY--     = SP_UPDATE_PERSON.--PRIMARY_KEY--,
    ATTR1               = SP_UPDATE_PERSON.ATTR1,
    ATTR2               = SP_UPDATE_PERSON.ATTR2,
    ATTR3               = SP_UPDATE_PERSON.ATTR3,
    DBMODIFYTIME        = sysdate,
    DBMODIFIEDBY        = USER
  WHERE
    USERID = SP_UPDATE_--SYNC_CLASS--.--PRIMARY_KEY--
  ;

 COMMIT;
END SP_UPDATE_--SYNC_CLASS--;

--
-- Stored Procedure for DELETE of --SYNC_CLASS--
--
-- Deletes a single row from --TABLE_NAME-- based on the primary key passed in.
--
CREATE OR REPLACE PROCEDURE SP_DELETE_--SYNC_CLASS-- (
  --PRIMARY_KEY-- IN VARCHAR2
) AS

BEGIN
   DELETE
     FROM --TABLE_NAME--
    WHERE --PRIMARY_KEY--=SP_DELETE_--SYNC_CLASS--.--PRIMARY_KEY--;

   COMMIT;
END SP_DELETE_--SYNC_CLASS--;